from setuptools import setup

setup(
    name="paq2grad",
    version="1.0",
    description="Ecuacion 2 grado",
    author="yo",
    packages=["segundo"]
)