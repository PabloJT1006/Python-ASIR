from math import *
def ecuacion(a,b,c):
    if(b*b-4*a*c) < 0:
        print("No se puede realizar")
    else:
        x1=(-b+sqrt(b*b-4*a*c))/(2*a)
        x2=(-b-sqrt(b*b-4*a*c))/(2*a)
        print("x1= ",x1,"x2= ",x2)