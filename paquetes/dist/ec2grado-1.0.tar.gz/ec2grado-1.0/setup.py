from setuptools import setup

setup(
    name="ec2grado",
    version="1.0",
    description="Paquete de ecuacion de segundo grado",
    author="Raul Tron",
    author_email="raulcmc3C@gmail.com",
    url="www.rauleelmejo.com",
    packages=["Modulo.ec2grado"]
)
